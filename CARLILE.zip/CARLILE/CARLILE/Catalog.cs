﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CARLILE
{
    public partial class Catalog : Form
    {
        private List<Item> items = new List<Item>();

        public Catalog()
        {
            InitializeComponent();
            LoadItemsFromDatabase(); 
            DisplayAllItems(); 
            InitializeCategoryComboBox();
        }

        private void basket_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void LoadItems()
        {
            string[] lines = File.ReadAllLines(@"C:\Users\user\Desktop\Шаброва\CARLILE\CARLILE\bin\Debug\catalog.txt");
            foreach (var line in lines)
            {
                string[] parts = line.Split('@');
                if (parts.Length == 5)
                {
                    string imagePath = parts[0];
                    string title = parts[1];
                    int quantity;
                    int sell;
                    string category = parts[4];
                    if (int.TryParse(parts[2], out quantity) && int.TryParse(parts[3], out sell))
                    {
                        items.Add(new Item { ImagePath = imagePath, Title = title, Quantity = quantity, Sell = sell, Category = category });
                    }
                }
            }

            MessageBox.Show($"Loaded {items.Count} items.");
        }

        private void DisplayAllItems()
        {
            catalogPanel.Controls.Clear(); // Clear the catalog panel before displaying new items
            foreach (var item in items)
            {
                AddItem(item.ImagePath, item.Title, item.Quantity, item.Sell); // Add each item to the panel
            }
        }

        private void LoadItemsFromDatabase()
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=THEGORGON;Integrated Security=True";
            string query = "SELECT photo, name, colvo, cost, categor FROM CataLLOG";

            items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string imagePath = reader["photo"].ToString();
                        string title = reader["name"].ToString();
                        int quantity = Convert.ToInt32(reader["colvo"]);
                        decimal price = Convert.ToDecimal(reader["cost"]);


                        items.Add(new Item { ImagePath = imagePath, Title = title, Quantity = quantity, Sell = price });
                    }
                }
            }
        }
        private void AddItem(string imagePath, string title, int quantity, decimal price)
        {
            Panel itemPanel = new Panel
            {
                Width = 150,
                Height = 220,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(5),
                BackColor = Color.Black,
                ForeColor = Color.White
            };

            PictureBox pictureBox = new PictureBox
            {
                Image = Image.FromFile(imagePath),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Width = 100,
                Height = 100,
                Location = new Point((itemPanel.Width - 100) / 2, 10)
            };

            Label titleLabel = new Label
            {
                Text = title,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Location = new Point(0, 120),
                Width = itemPanel.Width
            };

            Label quantityLabel = new Label
            {
                Text = $"{quantity} шт.",
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Location = new Point(0, 150),
                Width = itemPanel.Width
            };

            Label priceLabel = new Label
            {
                Text = $"{price} руб.",
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.White,
                Location = new Point(0, 180),
                Width = itemPanel.Width
            };

            itemPanel.Controls.Add(pictureBox);
            itemPanel.Controls.Add(titleLabel);
            itemPanel.Controls.Add(quantityLabel);
            itemPanel.Controls.Add(priceLabel);

            catalogPanel.Controls.Add(itemPanel); // Add the item panel to the catalog panel
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.ToLower();
            catalogPanel.Controls.Clear();

            var foundItem = items.FirstOrDefault(item => item.Title.ToLower().Contains(searchTerm));
            if (foundItem != null)
            {
                AddItem(foundItem.ImagePath, foundItem.Title, foundItem.Quantity, foundItem.Sell);
            }
            else
            {
                MessageBox.Show("Товар не найден");
            }
        }

        private void InitializeCategoryComboBox()
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.Add("Все");
            comboBox1.Items.Add("Бизнес");
            comboBox1.Items.Add("Органы");
            comboBox1.Items.Add("Оружие");
            comboBox1.Items.Add("Природа");
            comboBox1.Items.Add("Развлечения");
            comboBox1.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            comboBox1.SelectedIndex = 0;
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = comboBox1.SelectedItem.ToString();
            catalogPanel.Controls.Clear();
            var filteredItems = selectedCategory == "Все" ? items : items.Where(item => item.Category == selectedCategory);
            foreach (var item in filteredItems)
            {
                AddItem(item.ImagePath, item.Title, item.Quantity, item.Sell);
            }
        }

        private void sortButton_Click(object sender, EventArgs e)
        {
            items = items.OrderBy(item => item.Title).ToList();
            DisplayAllItems();
        }

        private void countSortButton_Click(object sender, EventArgs e)
        {
            items = items.OrderBy(item => item.Quantity).ToList();
            DisplayAllItems();
        }

        private void priceSortButton_Click(object sender, EventArgs e)
        {
            items = items.OrderBy(item => item.Sell).ToList();
            DisplayAllItems();
        }
    }

    public class Item
    {
        public string ImagePath { get; set; }
        public string Title { get; set; }
        public int Quantity { get; set; }
        public decimal  Sell { get; set; }
        public string Category { get; set; }
    }
}