﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace CARLILE
{
    public partial class ShopperReg : Form
    {
        Catalog catalog = new Catalog();
        public ShopperReg()
        {
            InitializeComponent();
        }
        //действие при прогрузке формы
        private void ShopperReg_Shown(object sender, EventArgs e)
        {
            //это, чтобы снять фокус со всех элементов
            this.ActiveControl = null;

            //пишем подсказку для пользователя
            emailTB.Text = "Email";
            emailTB.ForeColor = Color.Gray;


            //пишем подсказку для пользователя
            passTB.Text = "Password";
            passTB.ForeColor = Color.Gray;
            passTB.PasswordChar = '\0';
        }
        //это в случае, когда пользователь захочет ввести данные - мы убираем подсказку
        private void emailTB_Enter(object sender, EventArgs e)
        {
            if (emailTB.Text == "Email")
            {
                emailTB.Text = "";
                emailTB.ForeColor = Color.Black;
            }
        }
        //это в случае, когда пользователь оставит поле для ввода пустым - мы возвращаем подказку
        private void emailTB_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(emailTB.Text))
            {
                emailTB.Text = "Email";
                emailTB.ForeColor = Color.Gray;
            }
        }
        //это в случае, когда пользователь захочет ввести данные - мы убираем подсказку
        private void passTB_Enter(object sender, EventArgs e)
        {
            if (passTB.Text == "Password")
            {
                passTB.Text = "";
                passTB.ForeColor = Color.Black;
                passTB.PasswordChar = '·';
            }
        }
        //это в случае, когда пользователь оставит поле для ввода пустым - мы возвращаем подказку
        private void passTB_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(passTB.Text))
            {
                passTB.Text = "Password";
                passTB.ForeColor = Color.Gray;
                passTB.PasswordChar = '\0';
            }
        }

        //если пользователь хочет посмотреть пароль и удерживает элемент, отвечающий за это
        private void passShow_MouseDown(object sender, MouseEventArgs e)
        {
            passTB.PasswordChar = '\0';
        }

        //скрываем пароль, если пользователь не удерживает элемент
        private void passShow_MouseUp(object sender, MouseEventArgs e)
        {
            if (passTB.Text == "Password")
                passTB.PasswordChar = '\0';
            else
                passTB.PasswordChar = '·';
        }

        //мы зарегестрировались, ура
        private void regBT_Click(object sender, EventArgs e)
        {
            
            catalog.Show();
        }










        private void SendMessage(string email)
        {
            SmtpClient Smtp = new SmtpClient("smtp.mail.ru", 587);
            Smtp.EnableSsl = true;
            Smtp.Credentials = new NetworkCredential("agata_andreevna@mail.ru", "ExrbrJMgNfELNKuWcPS3");

            MailMessage Message = new MailMessage();
            Message.From = new MailAddress("agata_andreevna@mail.ru");
            Message.To.Add(new MailAddress($"{email}"));
            Message.Subject = "Добро пожаловать!";
            Message.Body = "Наша команда рада приветствовать вас в нашем магазине, удачных покупок!";

            try
            {
                Smtp.Send(Message);
            }
            catch (SmtpException smtpEx)
            {
                MessageBox.Show($"Ошибка при отправке письма: {smtpEx.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void ShopperReg_Load(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }
    }
}
