﻿namespace CARLILE
{
    partial class ShopperReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.emailTB = new System.Windows.Forms.TextBox();
            this.passTB = new System.Windows.Forms.TextBox();
            this.regBT = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.passShow = new System.Windows.Forms.PictureBox();
            this.firstPart = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passShow)).BeginInit();
            this.firstPart.SuspendLayout();
            this.SuspendLayout();
            // 
            // emailTB
            // 
            this.emailTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailTB.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.emailTB.Location = new System.Drawing.Point(12, 11);
            this.emailTB.Name = "emailTB";
            this.emailTB.Size = new System.Drawing.Size(213, 30);
            this.emailTB.TabIndex = 0;
            this.emailTB.Enter += new System.EventHandler(this.emailTB_Enter);
            this.emailTB.Leave += new System.EventHandler(this.emailTB_Leave);
            // 
            // passTB
            // 
            this.passTB.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passTB.Location = new System.Drawing.Point(12, 68);
            this.passTB.Name = "passTB";
            this.passTB.PasswordChar = '·';
            this.passTB.Size = new System.Drawing.Size(214, 30);
            this.passTB.TabIndex = 1;
            this.passTB.Enter += new System.EventHandler(this.passTB_Enter);
            this.passTB.Leave += new System.EventHandler(this.passTB_Leave);
            // 
            // regBT
            // 
            this.regBT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(64)))), ((int)(((byte)(60)))));
            this.regBT.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.regBT.ForeColor = System.Drawing.Color.White;
            this.regBT.Location = new System.Drawing.Point(27, 126);
            this.regBT.Name = "regBT";
            this.regBT.Size = new System.Drawing.Size(189, 40);
            this.regBT.TabIndex = 13;
            this.regBT.Text = "Register";
            this.regBT.UseVisualStyleBackColor = false;
            this.regBT.Click += new System.EventHandler(this.regBT_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::CARLILE.Properties.Resources.shopMen;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(574, 156);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 335);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::CARLILE.Properties.Resources.shopper;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(-1, -127);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(299, 747);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // passShow
            // 
            this.passShow.BackColor = System.Drawing.Color.White;
            this.passShow.BackgroundImage = global::CARLILE.Properties.Resources.eye;
            this.passShow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.passShow.Location = new System.Drawing.Point(195, 68);
            this.passShow.Name = "passShow";
            this.passShow.Size = new System.Drawing.Size(31, 30);
            this.passShow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.passShow.TabIndex = 12;
            this.passShow.TabStop = false;
            this.passShow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passShow_MouseDown);
            this.passShow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passShow_MouseUp);
            // 
            // firstPart
            // 
            this.firstPart.Controls.Add(this.regBT);
            this.firstPart.Controls.Add(this.passShow);
            this.firstPart.Controls.Add(this.passTB);
            this.firstPart.Controls.Add(this.emailTB);
            this.firstPart.Location = new System.Drawing.Point(313, 145);
            this.firstPart.Name = "firstPart";
            this.firstPart.Size = new System.Drawing.Size(237, 178);
            this.firstPart.TabIndex = 16;
            // 
            // ShopperReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.firstPart);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "ShopperReg";
            this.Text = "ShopperReg";
            this.Load += new System.EventHandler(this.ShopperReg_Load);
            this.Shown += new System.EventHandler(this.ShopperReg_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passShow)).EndInit();
            this.firstPart.ResumeLayout(false);
            this.firstPart.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox emailTB;
        private System.Windows.Forms.TextBox passTB;
        private System.Windows.Forms.PictureBox passShow;
        private System.Windows.Forms.Button regBT;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel firstPart;
    }
}