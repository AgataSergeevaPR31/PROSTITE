﻿namespace CARLILE
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.shopperBT = new System.Windows.Forms.PictureBox();
            this.merchantBT = new System.Windows.Forms.PictureBox();
            this.merchantReg = new System.Windows.Forms.Panel();
            this.shopperReg = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.shopperBT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.merchantBT)).BeginInit();
            this.merchantReg.SuspendLayout();
            this.shopperReg.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(1, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 34);
            this.label1.TabIndex = 3;
            this.label1.Text = "I\'m a Merchant";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(13, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 34);
            this.label2.TabIndex = 4;
            this.label2.Text = "I\'m a Shopper";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // shopperBT
            // 
            this.shopperBT.BackColor = System.Drawing.Color.White;
            this.shopperBT.BackgroundImage = global::CARLILE.Properties.Resources.bff34ad17044a9fff93cc879a5dc897b;
            this.shopperBT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.shopperBT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shopperBT.Location = new System.Drawing.Point(9, 3);
            this.shopperBT.Name = "shopperBT";
            this.shopperBT.Size = new System.Drawing.Size(215, 215);
            this.shopperBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.shopperBT.TabIndex = 2;
            this.shopperBT.TabStop = false;
            this.shopperBT.Click += new System.EventHandler(this.shopperBT_Click);
            // 
            // merchantBT
            // 
            this.merchantBT.BackColor = System.Drawing.Color.White;
            this.merchantBT.BackgroundImage = global::CARLILE.Properties.Resources.Adkaws;
            this.merchantBT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.merchantBT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.merchantBT.ErrorImage = null;
            this.merchantBT.Location = new System.Drawing.Point(7, 7);
            this.merchantBT.Name = "merchantBT";
            this.merchantBT.Size = new System.Drawing.Size(215, 215);
            this.merchantBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.merchantBT.TabIndex = 1;
            this.merchantBT.TabStop = false;
            this.merchantBT.Click += new System.EventHandler(this.merchantBT_Click);
            // 
            // merchantReg
            // 
            this.merchantReg.Controls.Add(this.label1);
            this.merchantReg.Controls.Add(this.merchantBT);
            this.merchantReg.Location = new System.Drawing.Point(111, 94);
            this.merchantReg.Name = "merchantReg";
            this.merchantReg.Size = new System.Drawing.Size(233, 270);
            this.merchantReg.TabIndex = 5;
            this.merchantReg.Click += new System.EventHandler(this.merchantReg_Go);
            // 
            // shopperReg
            // 
            this.shopperReg.Controls.Add(this.label2);
            this.shopperReg.Controls.Add(this.shopperBT);
            this.shopperReg.Location = new System.Drawing.Point(468, 98);
            this.shopperReg.Name = "shopperReg";
            this.shopperReg.Size = new System.Drawing.Size(232, 265);
            this.shopperReg.TabIndex = 6;
            this.shopperReg.Click += new System.EventHandler(this.shopperReg_Go);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.shopperReg);
            this.Controls.Add(this.merchantReg);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Registration";
            this.Text = "Registration";
            ((System.ComponentModel.ISupportInitialize)(this.shopperBT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.merchantBT)).EndInit();
            this.merchantReg.ResumeLayout(false);
            this.merchantReg.PerformLayout();
            this.shopperReg.ResumeLayout(false);
            this.shopperReg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox merchantBT;
        private System.Windows.Forms.PictureBox shopperBT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel merchantReg;
        private System.Windows.Forms.Panel shopperReg;
    }
}