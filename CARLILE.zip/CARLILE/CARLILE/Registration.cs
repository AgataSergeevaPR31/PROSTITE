﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CARLILE
{
    public partial class Registration : Form
    {
        //SignIn sign = new SignIn();
        ShopperReg shopperGo= new ShopperReg();
        MerchantReg merchantGo = new MerchantReg();
        public Registration()
        {
            InitializeComponent();
            //sign.Close();

            try
            {
                merchantBT.Image = Image.FromFile(@"C:\Users\user\Downloads\Adkaws.jpg");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
            }
        }


        private void shopperReg_Go(object sender, EventArgs e)
        {
            shopperGo.Show(); 
        }  

        private void shopperBT_Click(object sender, EventArgs e)
        {
            shopperGo.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            shopperGo.Show();
        }

        private void merchantReg_Go(object sender, EventArgs e)
        {
            merchantGo.Show();
        }

        private void merchantBT_Click(object sender, EventArgs e)
        {
            merchantGo.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            merchantGo.Show();
        }
    }
}
