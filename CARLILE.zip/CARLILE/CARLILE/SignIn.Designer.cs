﻿namespace CARLILE
{
    partial class SignIn
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignIn));
            this.titleLB = new System.Windows.Forms.Label();
            this.signInBT = new System.Windows.Forms.Button();
            this.roleCB = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.signUpBT = new System.Windows.Forms.Label();
            this.logTB = new System.Windows.Forms.TextBox();
            this.passTB = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLB
            // 
            this.titleLB.AutoSize = true;
            this.titleLB.Font = new System.Drawing.Font("Broadway", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLB.ForeColor = System.Drawing.Color.White;
            this.titleLB.Location = new System.Drawing.Point(407, 29);
            this.titleLB.Name = "titleLB";
            this.titleLB.Size = new System.Drawing.Size(309, 53);
            this.titleLB.TabIndex = 1;
            this.titleLB.Text = "The Gorgon";
            // 
            // signInBT
            // 
            this.signInBT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(56)))), ((int)(((byte)(175)))));
            this.signInBT.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.signInBT.ForeColor = System.Drawing.Color.White;
            this.signInBT.Location = new System.Drawing.Point(468, 282);
            this.signInBT.Name = "signInBT";
            this.signInBT.Size = new System.Drawing.Size(189, 40);
            this.signInBT.TabIndex = 4;
            this.signInBT.Text = "Sing In";
            this.signInBT.UseVisualStyleBackColor = false;
            this.signInBT.Click += new System.EventHandler(this.signInBT_Click);
            // 
            // roleCB
            // 
            this.roleCB.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roleCB.FormattingEnabled = true;
            this.roleCB.Location = new System.Drawing.Point(442, 124);
            this.roleCB.Name = "roleCB";
            this.roleCB.Size = new System.Drawing.Size(239, 29);
            this.roleCB.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(439, 346);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Don\'t have a profile yet?";
            // 
            // signUpBT
            // 
            this.signUpBT.AutoSize = true;
            this.signUpBT.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.signUpBT.ForeColor = System.Drawing.Color.White;
            this.signUpBT.Location = new System.Drawing.Point(625, 347);
            this.signUpBT.Name = "signUpBT";
            this.signUpBT.Size = new System.Drawing.Size(56, 16);
            this.signUpBT.TabIndex = 7;
            this.signUpBT.Text = "Sing Up";
            this.signUpBT.Click += new System.EventHandler(this.signUpBT_Click);
            // 
            // logTB
            // 
            this.logTB.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.logTB.Location = new System.Drawing.Point(442, 173);
            this.logTB.Name = "logTB";
            this.logTB.Size = new System.Drawing.Size(239, 30);
            this.logTB.TabIndex = 9;
            this.logTB.Enter += new System.EventHandler(this.logTB_Enter);
            this.logTB.Leave += new System.EventHandler(this.logTB_Leave);
            // 
            // passTB
            // 
            this.passTB.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passTB.Location = new System.Drawing.Point(442, 221);
            this.passTB.Name = "passTB";
            this.passTB.PasswordChar = '·';
            this.passTB.Size = new System.Drawing.Size(239, 30);
            this.passTB.TabIndex = 10;
            this.passTB.Enter += new System.EventHandler(this.passTB_Enter);
            this.passTB.Leave += new System.EventHandler(this.passTB_Leave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::CARLILE.Properties.Resources.eye;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(650, 221);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(31, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passTB_Show);
            this.pictureBox2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passTB_Hide);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(325, 452);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // SignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.logTB);
            this.Controls.Add(this.signUpBT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.roleCB);
            this.Controls.Add(this.signInBT);
            this.Controls.Add(this.titleLB);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SignIn";
            this.Text = "TheGorgonStore";
            this.Shown += new System.EventHandler(this.Registration_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label titleLB;
        private System.Windows.Forms.Button signInBT;
        private System.Windows.Forms.ComboBox roleCB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label signUpBT;
        private System.Windows.Forms.TextBox logTB;
        private System.Windows.Forms.TextBox passTB;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

