﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CARLILE
{
    public partial class SignIn : Form
    {
        Registration regScreen = new Registration();

        public SignIn()
        {
            InitializeComponent();


            //настройка ComboBox
            roleCB.DropDownStyle = ComboBoxStyle.DropDownList;

            roleCB.Items.Add("I'm a Shopper");
            roleCB.Items.Add("I'm a Merchant");
            roleCB.SelectedIndex = 0;

            try
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\user\Downloads\gorgone.png");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
            }
        }


        //доп. настройка формы 
        private void Registration_Shown(object sender, EventArgs e)
        {

            //настройка textBox Login
            logTB.Text = "Login";
            logTB.ForeColor = Color.Gray;

            //настройка textBox Password
            passTB.Text = "Password";
            passTB.ForeColor = Color.Gray;
            passTB.PasswordChar = '\0';

        }

        private void logTB_Enter(object sender, EventArgs e)
        {
            if (logTB.Text == "Login")
            {
                logTB.Text = "";
                logTB.ForeColor = Color.Black;
            }
        }

        private void logTB_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(logTB.Text))
            {
                logTB.Text = "Login";
                logTB.ForeColor = Color.Gray;
            }
        }

        private void passTB_Enter(object sender, EventArgs e)
        {
            if (passTB.Text == "Password")
            {
                passTB.Text = "";
                passTB.ForeColor = Color.Black;
                passTB.PasswordChar = '·';
            }
        }

        private void passTB_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(passTB.Text))
            {
                passTB.Text = "Password";
                passTB.ForeColor = Color.Gray;
                passTB.PasswordChar = '\0';
            }
        }

        //вход в маркетплэйс
        private void signInBT_Click(object sender, EventArgs e)
        {

        }

        //регистрация
        private void signUpBT_Click(object sender, EventArgs e)
        {
            regScreen.Show();
        }

        private void passTB_Show(object sender, MouseEventArgs e)
        {
            
            passTB.PasswordChar = '\0';
        }

        private void passTB_Hide(object sender, MouseEventArgs e)
        {
            if (passTB.Text == "Password")
                passTB.PasswordChar = '\0';
            else
                passTB.PasswordChar = '·';
        }
    }
}
